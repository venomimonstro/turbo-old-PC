Turbo Old PC v0.3.0 - preliminary build

Portable: double-click Turbo Old PC.vbs (no installation).
Install: double-click Install.cmd (installs for current user).
Console troubleshooting: Start.cmd

Security notes: scripts are currently unsigned; review origin and Windows warnings before execution. Make backups before changing important computers.
Full documentation and audit: https://github.com/venomimonstro/turbo-old-PC
